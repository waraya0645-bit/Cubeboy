# MyGame Unity C#版 — 数値CSVレイヤー編集版

このパッケージは `map-a` 専用です。マップの各レイヤーは `map-a.json` で編集し、オブジェクト配置は `objects.json` で編集します。WASDで移動、Eキーで正面の対象を調べます。

## 変更点

- 各マップ行を1文字方式から「カンマ区切りの整数」に変更しました。画像ID 100、200、201、1000などを使えます。
- 床、壁の見た目、装飾物の見た目、壁の当たり判定、装飾物の当たり判定をそれぞれ独立したレイヤーにしました。
- 画像IDと画像ファイル名の対応を `tileImageMap` で管理します。
- `MyGameController.cs` がJSONを読み、見た目の画像と衝突判定を作ります。

## 編集するファイル

### 1. マップデータ

`Assets/MyGame/Resources/MyGameData/map-a.json`

- `width`: 横のマス数（現在72）
- `height`: 縦のマス数（現在30）
- `pixelsPerTile`: 元の画像上の1マス（64ピクセル）
- `playerStartX`, `playerStartY`: プレイヤーの開始位置。左上を `(0,0)` として数えます。
- `floorRows`: 床。`0` は `black.png`、`1` は `floor.png`
- `wallVisualRows`: 壁の見た目。`0` は画像なし、`100` などは画像ID
- `decorationVisualRows`: 装飾物の見た目。`0` は画像なし、`200` などは画像ID
- `wallCollisionRows`: 壁の当たり判定。`0` は通行可能、`1` は通行不可
- `decorationCollisionRows`: 装飾物の当たり判定。`0` は通行可能、`1` は通行不可
- `tileImageMap`: 見た目レイヤーの画像IDと画像名の対応表。画像名は `.png` を付けずに記入します。

### 2. カンマ区切りの行の書き方

マップは横72マスなので、**各レイヤーは30行、各行はカンマで区切った72個の整数**にします。例えば幅4マスの小さな例なら次のようになります（実際の72マスのデータをこの例で置き換えないでください）。

```json
"wallVisualRows": [
  "0,0,0,100",
  "0,0,200,0",
  "0,201,0,0",
  "0,0,0,0"
]
```

`0` は見た目画像なしです。`100` は画像ID 100、`200` は画像ID 200というように、桁数の制限なく番号を指定できます。行の中では、左からX=0、X=1、X=2…の順で並びます。最初の行がY=0です。

実際の72×30マップで1マス変えるときは、編集したいレイヤーの該当行の数値1個だけを変更してください。**カンマの数や他の数値を消さないように注意してください。** 保存時にUnity側が各行72個かを検査し、足りない場合はエラーを出します。

### 3. 画像IDの対応表

同じ `map-a.json` の `tileImageMap` に追加します。例えば:

```json
"tileImageMap": [
  { "id": 100, "image": "stone_wall" },
  { "id": 200, "image": "dot-Mygame_20261009081021" },
  { "id": 201, "image": "red_key" },
  { "id": 300, "image": "my_new_decoration" }
]
```

上の300は例です。実際には `Resources/MyGameSprites/my_new_decoration.png` が存在する必要があります。画像IDはマップ内で何度も使ってかまいませんが、`tileImageMap` 側で同じIDを二重登録しないでください。

壁の見た目に `100` を置けば `stone_wall.png`、装飾物の見た目に `200` を置けば `dot-Mygame_20261009081021.png` が表示されます。画像ファイルを増やしたら、PNGを `Assets/MyGame/Resources/MyGameSprites/` に追加し、対応するIDと画像名を `tileImageMap` に追加します。

### 4. 当たり判定と見た目は別々

- 壁の見た目だけに `100` を設定しても、自動的に通行不可にはなりません。
- 通行不可にするには、同じマスの `wallCollisionRows` を `1` にします。
- 装飾物の当たり判定は `decorationCollisionRows` で別に指定します。
- 当たり判定レイヤーは `0` と `1` だけを使います。

### 5. オブジェクトの配置

`Assets/MyGame/Resources/MyGameData/objects.json`

このファイルは従来どおり `tileX`, `tileY`, `image`, `hitboxWidth`, `hitboxHeight`, `interactable`, `interactionType`, `initiallyActive`, `revealsObjectId`, `itemId` で編集します。マップのタイル画像レイヤーと、Eキーで調べるオブジェクトは別管理です。

## スマホのGitHubでの編集

1. `unity-version` ブランチを開きます。
2. `Assets/MyGame/Resources/MyGameData/map-a.json` または `objects.json` を開き、鉛筆マークを押します。
3. 変更を加えて `Commit changes` で保存します。

このパッケージのZIPを既存のZIPと同じ `Unity_MyGame.zip` という名前でリポジトリ直下にアップロードすると、設定済みのGitHub Actionsが動作し、`Assets/MyGame` を更新する想定です。

## Unityへの導入

1. ZIPを展開し、中の `unity_mygame/Assets/MyGame` をUnityプロジェクトの `Assets/MyGame` にコピーします。
2. `Resources/MyGameSprites` のPNGを Sprite として読み込みます（Pixels Per Unit=64、Filter Mode=Point、Compression=None）。
3. Hierarchyに空オブジェクト `GameController` を作り、`MyGameController.cs` を追加します。
4. UnityでPlayし、START後にWASD移動、Eで調べる動作を確認します。

**注意:** この環境ではUnityの実行テストはできていません。JSONの構造、30行・72個/行のデータ個数は生成時に検証しています。
