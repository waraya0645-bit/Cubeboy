# MyGame Unity C#版 — スマホから編集しやすいデータ分離版

このフォルダーは元の `my-game-split-files.zip` の `map-a.js` と画像をもとにした、map-a専用のUnity用パッケージです。
**マップの配列やオブジェクト配置を変更するために、MyGameController.csを編集する必要はありません。**

## 編集するファイル

### 1. マップの床・壁・開始位置

`Assets/MyGame/Resources/MyGameData/map-a.json`

- `width`: 横のマス数（現在72）
- `height`: 縦のマス数（現在30）
- `pixelsPerTile`: 元画像上の1マスの大きさ（現在64）
- `playerStartX`, `playerStartY`: プレイヤー開始マス。左上を (0, 0) として数えます。
- `floorRows`: 床の見た目。`0` は black.png、`1` は floor.png
- `wallCollisionRows`: 壁の当たり判定。`0` は通行可能、`1` は壁

`floorRows` と `wallCollisionRows` は「1行＝1つの文字列」です。現在は横72文字が縦30行あります。左の文字がX=0、次がX=1です。最初の行がY=0です。**マップの幅や高さを変更する場合は、width・heightだけでなく、両方の行数と各行の文字数も一致させてください。** 形が合わない場合はゲーム側がエラーを出して停止します。

例（幅4の小さな例です。実際のマップをこの例で置き換えないでください）:

```json
"floorRows": [
  "0000",
  "0110",
  "0110",
  "0000"
],
"wallCollisionRows": [
  "1111",
  "1001",
  "1001",
  "1111"
]
```

### 2. オブジェクトの座標・画像・動作

`Assets/MyGame/Resources/MyGameData/objects.json`

オブジェクトは `objects` 配列の中に1つずつ書きます。

- `id`: オブジェクトを識別する名前。**必ず一意**にします。
- `tileX`, `tileY`: 置くマス。左上が (0, 0)。
- `image`: `Resources/MyGame/Resources/MyGameSprites` 内の画像名から `.png` を除いたもの
- `hitboxWidth`, `hitboxHeight`: 当たり判定の幅・高さ（元画像と同じピクセル単位）
- `interactable`: Eキーで調べられるか
- `interactionType`: `reveal` または `pickup`、それ以外は調べたときにメッセージだけ表示
- `initiallyActive`: ゲーム開始時に表示するか
- `revealsObjectId`: `reveal` のとき、消えた後に表示する別オブジェクトの `id`
- `itemId`: `pickup` のとき、取得数表示に使う名前（空なら `id` を使います）

現在のサンプルは、`dot` を調べると `dot` が消えて `key` が表示され、もう一度Eを押すと鍵を取得する設定です。

画像を追加する場合はPNGを `Assets/MyGame/Resources/MyGameSprites/` に入れ、Unity上で Sprite として読み込める設定にしてください。`image` には画像ファイル名（拡張子を除く）を書きます。

## スマホのGitHub編集画面で変更する流れ

1. GitHubでUnity版のファイルを置いたブランチを開きます。
2. `Assets/MyGame/Resources/MyGameData/map-a.json` または `objects.json` を開きます。
3. 鉛筆マーク（Edit）を押します。
4. JSON内の数値や文字を変更します。カンマ・引用符・角括弧を消さないように注意してください。
5. 画面下部の Commit changes で変更を保存します。

**このパッケージを作っただけでは、GitHubのリポジトリは変更されていません。** これは差し替え用ファイル一式です。既存のUnity版ファイルと置き換えてから、上記JSONファイルをGitHubで編集します。

## Unityに入れるとき

1. Unity 2Dプロジェクトへ `Assets/MyGame` フォルダーをコピーします（既存の同名ファイルを更新してください）。
2. `Resources/MyGameSprites` 内のPNGを選び、Texture Type=`Sprite (2D and UI)`、Pixels Per Unit=`64`、Filter Mode=`Point (no filter)`、Compression=`None` に設定してApply。
3. Hierarchyの空オブジェクトへ `MyGameController.cs` を追加します。
4. Input Handling が New Input System のみの場合は、Active Input Handlingを `Both` または `Input Manager (Old)` にします。
5. Playを押してSTARTを選び、WASDで移動、Eで調べます。

## 含まれるもの

- `Assets/MyGame/Scripts/MyGameController.cs`: ゲーム処理
- `Assets/MyGame/Scripts/MapAData.cs`: マップJSONの読み取り・形式確認
- `Assets/MyGame/Scripts/ObjectData.cs`: オブジェクトJSONの形式
- `Assets/MyGame/Resources/MyGameData/map-a.json`: 編集用マップデータ
- `Assets/MyGame/Resources/MyGameData/objects.json`: 編集用オブジェクトデータ
- `Assets/MyGame/Resources/MyGameSprites/`: 画像素材

Unityでの実行はこの環境では確認できていません。JSONの行数・文字数・形式は作成時に確認しています。
